import { NextRequest } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'
import {
  createApiError,
  createApiSuccess,
  requireApiKey,
  resolveDateRange,
  toNumber,
  validateClientScope
} from '@/app/api/v1/_lib/api-v1-utils'
import { resolveScopedCampaign } from '@/app/api/v1/_lib/campaign-helpers'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ campaignId: string }> }
) {
  const authResult = await requireApiKey(request, 'campaigns:read')
  if (authResult.ok === false) {
    return authResult.response
  }

  const { campaignId } = await params
  const searchParams = request.nextUrl.searchParams
  const clientId = searchParams.get('client_id')?.trim()

  if (!clientId) {
    return createApiError(400, 'MISSING_CLIENT_ID', 'Query parameter client_id is required')
  }

  const includeInsights = searchParams.get('include_insights') === 'true'

  try {
    const scopedClient = await validateClientScope(clientId, authResult.auth.organizationId)
    if (!scopedClient.ok) {
      return scopedClient.response
    }

    const campaign = await resolveScopedCampaign(clientId, campaignId)
    if (!campaign) {
      return createApiError(404, 'CAMPAIGN_NOT_FOUND', 'Campaign not found for this client')
    }

    if (!includeInsights) {
      return createApiSuccess(
        {
          client_id: clientId,
          client_name: scopedClient.client.name ?? null,
          campaign: {
            id: campaign.id,
            name: campaign.name,
            status: campaign.status,
            objective: campaign.objective,
            daily_budget: campaign.daily_budget,
            lifetime_budget: campaign.lifetime_budget,
            updated_time: campaign.updated_time,
            account_id: campaign.connection.ad_account_id,
            account_name: campaign.connection.account_name
          }
        },
        { warnings: [] }
      )
    }

    let dateRange
    try {
      dateRange = resolveDateRange(searchParams)
    } catch (error) {
      if (error instanceof Error && error.message === 'INVALID_DATE_FORMAT') {
        return createApiError(422, 'INVALID_DATE_FORMAT', 'Use date format YYYY-MM-DD for date_from and date_to')
      }

      if (error instanceof Error && error.message === 'INVALID_DATE_RANGE') {
        return createApiError(422, 'INVALID_DATE_RANGE', 'date_from must be before or equal to date_to')
      }

      return createApiError(422, 'INVALID_DATE_RANGE_INPUT', 'Invalid date range')
    }

    const supabase = createServiceClient()
    const { data: insights, error } = await supabase
      .from('meta_campaign_insights')
      .select('date_start, date_stop, impressions, clicks, spend, reach, conversions')
      .eq('campaign_id', campaignId)
      .gte('date_start', dateRange.dateFrom)
      .lte('date_start', dateRange.dateTo)
      .order('date_start', { ascending: true })

    if (error) {
      console.error('[v1/campaigns/:id] insights fetch error:', error)
      return createApiError(500, 'INSIGHTS_FETCH_FAILED', 'Failed to fetch campaign insights')
    }

    const daily = (insights ?? []).map((row: any) => ({
      date_start: row.date_start,
      date_stop: row.date_stop,
      impressions: Math.round(toNumber(row.impressions)),
      clicks: Math.round(toNumber(row.clicks)),
      reach: Math.round(toNumber(row.reach)),
      conversions: Number(toNumber(row.conversions).toFixed(2)),
      spend: Number(toNumber(row.spend).toFixed(2))
    }))

    const summary = daily.reduce(
      (acc, row) => {
        acc.impressions += row.impressions
        acc.clicks += row.clicks
        acc.reach += row.reach
        acc.conversions += row.conversions
        acc.spend += row.spend
        return acc
      },
      { impressions: 0, clicks: 0, reach: 0, conversions: 0, spend: 0 }
    )

    return createApiSuccess(
      {
        client_id: clientId,
        client_name: scopedClient.client.name ?? null,
        campaign: {
          id: campaign.id,
          name: campaign.name,
          status: campaign.status,
          objective: campaign.objective,
          daily_budget: campaign.daily_budget,
          lifetime_budget: campaign.lifetime_budget,
          updated_time: campaign.updated_time,
          account_id: campaign.connection.ad_account_id,
          account_name: campaign.connection.account_name
        },
        insights: {
          summary: {
            impressions: summary.impressions,
            clicks: summary.clicks,
            reach: summary.reach,
            conversions: Number(summary.conversions.toFixed(2)),
            spend: Number(summary.spend.toFixed(2))
          },
          daily
        }
      },
      {
        date_range: {
          date_from: dateRange.dateFrom,
          date_to: dateRange.dateTo,
          date_default_applied: dateRange.dateDefaultApplied
        },
        warnings: dateRange.warnings
      }
    )
  } catch (error) {
    console.error('[v1/campaigns/:id] unexpected error:', error)
    return createApiError(500, 'INTERNAL_SERVER_ERROR', 'Internal server error')
  }
}

